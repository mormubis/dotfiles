import React from "react";

interface Props {}

const ${NAME} = (props: Props) => {
    return null;
}

export default ${NAME};